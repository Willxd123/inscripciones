import { IsInt, IsPositive, IsOptional, IsDateString, IsArray, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

class DetalleInscripcionDto {
  @IsInt()
  @IsPositive()
  grupoMateriaId: number;
}

export class CreateInscripcionDto {
  @IsDateString()
  @IsOptional()
  fechaInscripcion?: Date;

  @IsInt()
  @IsPositive()
  estudianteId: number;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => DetalleInscripcionDto)
  @IsOptional()
  detalles?: DetalleInscripcionDto[];
}