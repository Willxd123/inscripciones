// create-detalle-inscripcion.dto.ts
export class CreateDetalleInscripcionDto {
    inscripcion: { id: number };
    grupoMateria: { id: number };
  }