import { Entity, PrimaryColumn, Column, UpdateDateColumn, CreateDateColumn } from 'typeorm';

@Entity({ name: 'queue_config' })
export class QueueConfig {
  @PrimaryColumn({ length: 50 })
  serviceName: string; // 'carrera', 'materia', 'docente', etc.

  @Column({ name: 'use_queue', default: false })
  useQueue: boolean; // true = usa cola, false = síncrono

  // NUEVOS CAMPOS PARA WORKER QUEUES
  @Column({ name: 'worker_queue_name', length: 50, nullable: true })
  workerQueueName: string; // 'worker-queue-1', 'worker-queue-2', etc.

  @Column({ name: 'worker_queue_concurrency', type: 'int', default: 1 })
  workerQueueConcurrency: number; // workers por esta cola

  @Column({ name: 'assigned_services', type: 'json', nullable: true })
  assignedServices: string[]; // ['estudiante', 'inscripcion'] o ['*']

  @Column({ name: 'is_worker_queue', default: false })
  isWorkerQueue: boolean; // true = configuración de worker queue, false = configuración de servicio

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}