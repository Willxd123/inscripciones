import { PartialType } from '@nestjs/mapped-types';
import { CreateDocenteDto } from './create-docente.dto';

export class UpdateDocenteDto extends (PartialType as any)(CreateDocenteDto) {}
