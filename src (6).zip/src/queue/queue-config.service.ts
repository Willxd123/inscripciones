import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { Queue } from 'bull';
import { InjectQueue } from '@nestjs/bull';
import { GENERIC_QUEUE } from './generic-queue.processor';
import * as fs from 'fs';
import * as path from 'path';
import { watch } from 'fs';

export interface ServiceConfig {
  useQueue: boolean;
  isPaused: boolean;
}

export interface WorkerQueueConfig {
  enabled: boolean;
  concurrency: number;
  assignedServices: string[];
  description: string;
  createdAt: string;
}

export interface QueueConfigData {
  version: string;
  lastUpdated: string;
  metadata: {
    totalServices: number;
    totalWorkerQueues: number;
    defaultConcurrency: number;
  };
  services: Record<string, ServiceConfig>;
  workerQueues: Record<string, WorkerQueueConfig>;
}

@Injectable()
export class QueueConfigService implements OnModuleInit {
  private readonly logger = new Logger(QueueConfigService.name);
  private readonly configPath = path.join(process.cwd(), 'src', 'queue', 'queue-config.json');
  private config: QueueConfigData;
  private queueRegistry: Map<string, Queue> = new Map();
  private isWriting = false; // Mutex simple para escrituras

  constructor(
    @InjectQueue(GENERIC_QUEUE) private readonly genericQueue: Queue,
  ) {}

  async onModuleInit() {
    this.logger.log('🚀 Iniciando QueueConfigService con JSON...');
    
    // Cargar configuración inicial
    await this.loadConfigFromJson();
    
    // Registrar la cola genérica
    this.registerGenericQueue();
    
    // Configurar watcher para recarga automática
    this.setupFileWatcher();
    
    this.logger.log(`✅ QueueConfigService listo - ${Object.keys(this.config.services).length} servicios, ${Object.keys(this.config.workerQueues).length} worker queues`);
  }

  /**
   * Carga la configuración desde el archivo JSON
   */
  private async loadConfigFromJson(): Promise<void> {
    try {
      if (!fs.existsSync(this.configPath)) {
        this.logger.warn(`📁 Archivo ${this.configPath} no existe, creando configuración inicial`);
        await this.createDefaultJsonConfig();
      }

      const configContent = fs.readFileSync(this.configPath, 'utf8');
      this.config = JSON.parse(configContent);
      
      this.validateJsonConfig();
      this.logger.log(`📋 Configuración cargada: v${this.config.version} - ${this.config.metadata.totalServices} servicios`);
      
    } catch (error) {
      this.logger.error('❌ Error cargando queue-config.json:', error.message);
      await this.createEmergencyConfig();
    }
  }

  /**
   * Crea el archivo JSON con configuración por defecto
   */
  private async createDefaultJsonConfig(): Promise<void> {
    // Asegurar que el directorio existe
    const configDir = path.dirname(this.configPath);
    if (!fs.existsSync(configDir)) {
      fs.mkdirSync(configDir, { recursive: true });
    }

    const defaultConfig: QueueConfigData = {
      version: "1.0.0",
      lastUpdated: new Date().toISOString(),
      metadata: {
        totalServices: 18,
        totalWorkerQueues: 2,
        defaultConcurrency: 1
      },
      services: {
        "carrera": { useQueue: true, isPaused: false },
        "plan-estudio": { useQueue: true, isPaused: false },
        "estudiante": { useQueue: true, isPaused: false },
        "inscripcion": { useQueue: true, isPaused: false },
        "detalle-inscripcion": { useQueue: true, isPaused: false },
        "aula": { useQueue: true, isPaused: false },
        "boleta-horario": { useQueue: true, isPaused: false },
        "docente": { useQueue: true, isPaused: false },
        "gestion": { useQueue: true, isPaused: false },
        "grupo": { useQueue: true, isPaused: false },
        "grupo-materia": { useQueue: true, isPaused: false },
        "horario": { useQueue: true, isPaused: false },
        "materia": { useQueue: true, isPaused: false },
        "modulo": { useQueue: true, isPaused: false },
        "nivel": { useQueue: true, isPaused: false },
        "nota": { useQueue: true, isPaused: false },
        "periodo": { useQueue: true, isPaused: false },
        "prerequisito": { useQueue: true, isPaused: false }
      },
      workerQueues: {
        "worker-queue-1": {
          enabled: true,
          concurrency: 1,
          assignedServices: ["carrera", "estudiante", "inscripcion", "detalle-inscripcion"],
          description: "Cola prioritaria para operaciones críticas",
          createdAt: new Date().toISOString()
        },
        "worker-queue-2": {
          enabled: true,
          concurrency: 1,
          assignedServices: ["*"],
          description: "Cola general catch-all para resto de servicios",
          createdAt: new Date().toISOString()
        }
      }
    };

    await this.writeConfigToJson(defaultConfig);
    this.config = defaultConfig;
    this.logger.log('✅ Archivo queue-config.json creado con configuración por defecto');
  }

  /**
   * Configuración de emergencia si todo falla
   */
  private async createEmergencyConfig(): Promise<void> {
    this.config = {
      version: "emergency",
      lastUpdated: new Date().toISOString(),
      metadata: {
        totalServices: 0,
        totalWorkerQueues: 0,
        defaultConcurrency: 1
      },
      services: {},
      workerQueues: {}
    };
    
    this.logger.warn('⚠️ Usando configuración de emergencia (sin servicios configurados)');
  }

  /**
   * Valida la estructura del JSON
   */
  private validateJsonConfig(): void {
    if (!this.config.version || !this.config.services || !this.config.workerQueues || !this.config.metadata) {
      throw new Error('Estructura de queue-config.json inválida');
    }
  }

  /**
   * Escribe la configuración al archivo JSON de forma segura
   */
  private async writeConfigToJson(config: QueueConfigData): Promise<void> {
    if (this.isWriting) {
      this.logger.warn('⏳ Escritura en progreso, esperando...');
      // Esperar un poco y reintentar
      await new Promise(resolve => setTimeout(resolve, 50));
      return this.writeConfigToJson(config);
    }

    this.isWriting = true;
    
    try {
      // Crear backup
      const backupPath = this.configPath + '.backup';
      if (fs.existsSync(this.configPath)) {
        fs.copyFileSync(this.configPath, backupPath);
      }

      // Actualizar metadata
      config.lastUpdated = new Date().toISOString();
      config.metadata.totalServices = Object.keys(config.services).length;
      config.metadata.totalWorkerQueues = Object.keys(config.workerQueues).length;

      // Escribir archivo temporal primero
      const tempPath = this.configPath + '.tmp';
      fs.writeFileSync(tempPath, JSON.stringify(config, null, 2));
      
      // Mover archivo temporal al definitivo (operación atómica)
      fs.renameSync(tempPath, this.configPath);
      
      this.logger.debug('💾 Configuración guardada en queue-config.json');
      
    } catch (error) {
      this.logger.error('❌ Error escribiendo queue-config.json:', error.message);
      throw error;
    } finally {
      this.isWriting = false;
    }
  }

  /**
   * Configura el watcher para recarga automática
   */
  private setupFileWatcher(): void {
    try {
      watch(this.configPath, { persistent: false }, (eventType) => {
        if (eventType === 'change' && !this.isWriting) {
          this.logger.log('🔄 Cambios detectados en queue-config.json, recargando...');
          setTimeout(() => {
            this.loadConfigFromJson().catch(error => {
              this.logger.error('❌ Error recargando configuración:', error.message);
            });
          }, 100);
        }
      });
      
      this.logger.log('👀 File watcher configurado para queue-config.json');
    } catch (error) {
      this.logger.warn('⚠️ No se pudo configurar file watcher:', error.message);
    }
  }

  private registerGenericQueue(): void {
    this.logger.log('📋 Cola genérica registrada para todos los servicios');
  }

  // ============ MÉTODOS PÚBLICOS (COMPATIBILIDAD CON CONTROLLER) ============

  /**
   * Obtener configuración de un servicio (SÚPER RÁPIDO - Solo memoria)
   */
  async getServiceConfig(serviceName: string): Promise<{ useQueue: boolean; isPaused: boolean }> {
    const serviceConfig = this.config.services[serviceName];
    
    if (!serviceConfig) {
      // Si no existe, usar configuración por defecto
      return {
        useQueue: false,
        isPaused: false,
      };
    }

    return {
      useQueue: serviceConfig.useQueue,
      isPaused: serviceConfig.isPaused,
    };
  }

  /**
   * Cambiar modo de un servicio (síncrono ↔ asíncrono)
   */
  async setServiceQueueMode(serviceName: string, useQueue: boolean): Promise<void> {
    if (!this.config.services[serviceName]) {
      this.config.services[serviceName] = {
        useQueue,
        isPaused: false
      };
    } else {
      this.config.services[serviceName].useQueue = useQueue;
    }

    await this.writeConfigToJson(this.config);
    this.logger.log(`🔄 Servicio ${serviceName} configurado para ${useQueue ? 'COLA' : 'SÍNCRONO'}`);
  }

  /**
   * Pausar cola de un servicio
   */
  async pauseQueue(serviceName: string): Promise<void> {
    if (this.config.services[serviceName]) {
      this.config.services[serviceName].isPaused = true;
      await this.writeConfigToJson(this.config);
      this.logger.log(`⏸️ Cola del servicio ${serviceName} pausada`);
    }
  }

  /**
   * Reanudar cola de un servicio
   */
  async resumeQueue(serviceName: string): Promise<void> {
    if (this.config.services[serviceName]) {
      this.config.services[serviceName].isPaused = false;
      await this.writeConfigToJson(this.config);
      this.logger.log(`▶️ Cola del servicio ${serviceName} reanudada`);
    }
  }

  /**
   * Verificar si una cola está pausada
   */
  async isQueuePaused(serviceName: string): Promise<boolean> {
    return this.config.services[serviceName]?.isPaused || false;
  }

  /**
   * Listar todos los servicios y su configuración
   */
  async getAllServicesConfig(): Promise<Array<{ serviceName: string; useQueue: boolean; isPaused: boolean }>> {
    return Object.entries(this.config.services).map(([serviceName, config]) => ({
      serviceName,
      useQueue: config.useQueue,
      isPaused: config.isPaused,
    }));
  }

  /**
   * Verificar si un servicio debe usar cola (CRÍTICO PARA PERFORMANCE)
   */
  async shouldUseQueue(serviceName: string): Promise<boolean> {
    const serviceConfig = this.config.services[serviceName];
    return serviceConfig?.useQueue || false;
  }

  /**
   * Verificar si debe procesar la cola
   */
  async shouldProcessQueue(serviceName: string): Promise<boolean> {
    const serviceConfig = this.config.services[serviceName];
    return (serviceConfig?.useQueue && !serviceConfig?.isPaused) || false;
  }

  // ============ MÉTODOS PARA WORKER QUEUES ============

  /**
   * Crear nueva worker queue
   */
  async createWorkerQueue(
    workerQueueName: string,
    concurrency: number,
    services: string[]
  ): Promise<void> {
    this.config.workerQueues[workerQueueName] = {
      enabled: true,
      concurrency,
      assignedServices: services,
      description: `Worker queue con ${concurrency} workers`,
      createdAt: new Date().toISOString()
    };

    await this.writeConfigToJson(this.config);
    this.logger.log(`✅ Worker queue ${workerQueueName} creada con ${concurrency} workers y servicios: ${services.join(', ')}`);
  }

  /**
   * Eliminar worker queue
   */
  async removeWorkerQueue(workerQueueName: string): Promise<void> {
    if (this.config.workerQueues[workerQueueName]) {
      delete this.config.workerQueues[workerQueueName];
      await this.writeConfigToJson(this.config);
      this.logger.log(`🗑️ Worker queue ${workerQueueName} eliminada`);
    }
  }

  /**
   * Actualizar servicios de una worker queue
   */
  async updateWorkerQueueServices(workerQueueName: string, services: string[]): Promise<void> {
    if (this.config.workerQueues[workerQueueName]) {
      this.config.workerQueues[workerQueueName].assignedServices = services;
      await this.writeConfigToJson(this.config);
      this.logger.log(`🔄 Servicios de ${workerQueueName} actualizados: ${services.join(', ')}`);
    }
  }

  /**
   * Actualizar concurrencia de una worker queue
   */
  async updateWorkerQueueConcurrency(workerQueueName: string, concurrency: number): Promise<void> {
    if (this.config.workerQueues[workerQueueName]) {
      this.config.workerQueues[workerQueueName].concurrency = concurrency;
      await this.writeConfigToJson(this.config);
      this.logger.log(`⚡ Concurrencia de ${workerQueueName} actualizada a ${concurrency} workers`);
    }
  }

  /**
   * Obtener todas las worker queues
   */
  async getAllWorkerQueues(): Promise<any[]> {
    return Object.entries(this.config.workerQueues).map(([workerQueueName, config]) => ({
      workerQueueName,
      workerQueueConcurrency: config.concurrency,
      assignedServices: config.assignedServices,
      enabled: config.enabled,
      description: config.description,
      createdAt: config.createdAt
    }));
  }

  /**
   * Obtener configuración de una worker queue específica
   */
  async getWorkerQueueConfig(workerQueueName: string): Promise<any | null> {
    const config = this.config.workerQueues[workerQueueName];
    
    if (!config) {
      return null;
    }

    return {
      workerQueueName,
      workerQueueConcurrency: config.concurrency,
      assignedServices: config.assignedServices,
      enabled: config.enabled,
      description: config.description,
      createdAt: config.createdAt
    };
  }

  /**
   * Obtener worker queues que pueden atender un servicio específico
   */
  async getWorkerQueuesForService(serviceName: string): Promise<any[]> {
    return Object.entries(this.config.workerQueues)
      .filter(([_, config]) => 
        config.enabled && (
          config.assignedServices.includes(serviceName) || 
          config.assignedServices.includes('*')
        )
      )
      .map(([workerQueueName, config]) => ({
        workerQueueName,
        workerQueueConcurrency: config.concurrency,
        assignedServices: config.assignedServices
      }));
  }

  /**
   * Verificar si existe al menos una worker queue
   */
  async hasWorkerQueues(): Promise<boolean> {
    return Object.keys(this.config.workerQueues).length > 0;
  }

  // ============ MÉTODOS ADICIONALES ============

  /**
   * Obtener toda la configuración (para debugging)
   */
  getFullConfig(): QueueConfigData {
    return { ...this.config };
  }
}