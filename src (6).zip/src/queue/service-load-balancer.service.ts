import { Injectable, Logger } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { QueueConfigService } from './queue-config.service';
import { GENERIC_QUEUE } from './generic-queue.processor';

export interface LoadBalancerResult {
  workerQueueName: string;
  waitingJobs: number;
  activeJobs: number;
  totalJobs: number;
  reason: string;
}

@Injectable()
export class ServiceLoadBalancerService {
  private readonly logger = new Logger(ServiceLoadBalancerService.name);

  constructor(
    private readonly queueConfigService: QueueConfigService,
    @InjectQueue(GENERIC_QUEUE) private readonly genericQueue: Queue,
  ) {}

 
  async selectWorkerQueue(serviceName: string): Promise<LoadBalancerResult | null> {
    // PASO 1: Verificar si el servicio debe usar colas
    const shouldUseQueue = await this.queueConfigService.shouldUseQueue(serviceName);
    
    if (!shouldUseQueue) {
      this.logger.debug(`Servicio ${serviceName} configurado como SÍNCRONO - no usa worker queues`);
      return null;
    }

    // PASO 2: Obtener worker queues que pueden atender este servicio
    const eligibleQueues = await this.queueConfigService.getWorkerQueuesForService(serviceName);

    if (eligibleQueues.length === 0) {
      this.logger.warn(`No hay worker queues configuradas para el servicio ${serviceName}`);
      return null;
    }

    // PASO 3: Obtener estadísticas de cada worker queue elegible
    const queueStats = await Promise.all(
      eligibleQueues.map(async (queueConfig) => {
        const stats = await this.getWorkerQueueStats(queueConfig.workerQueueName);
        return {
          queueConfig,
          ...stats,
        };
      })
    );

    // PASO 4: Seleccionar la menos cargada (menos trabajos esperando)
    const selectedQueue = queueStats.reduce((least, current) => {
      // Prioridad: menos trabajos esperando, luego menos trabajos activos
      if (current.waitingJobs < least.waitingJobs) {
        return current;
      } else if (current.waitingJobs === least.waitingJobs && current.activeJobs < least.activeJobs) {
        return current;
      }
      return least;
    });

    const result: LoadBalancerResult = {
      workerQueueName: selectedQueue.queueConfig.workerQueueName,
      waitingJobs: selectedQueue.waitingJobs,
      activeJobs: selectedQueue.activeJobs,
      totalJobs: selectedQueue.totalJobs,
      reason: `Menos cargada entre ${queueStats.length} worker queues elegibles`,
    };

    this.logger.debug(
      `Servicio ${serviceName} → ${result.workerQueueName} ` +
      `(waiting: ${result.waitingJobs}, active: ${result.activeJobs})`
    );

    return result;
  }

  /**
   * Obtiene estadísticas de trabajos para una worker queue específica
   * @param workerQueueName Nombre de la worker queue
   * @returns Estadísticas de la cola
   */
  private async getWorkerQueueStats(workerQueueName: string) {
    try {
      // Obtener todos los trabajos de la cola genérica
      const waiting = await this.genericQueue.getWaiting();
      const active = await this.genericQueue.getActive();
      const completed = await this.genericQueue.getCompleted();
      const failed = await this.genericQueue.getFailed();

      // Filtrar trabajos que pertenecen a esta worker queue específica
      const queueWaiting = waiting.filter(job => 
        job.data.workerQueueName === workerQueueName
      );
      const queueActive = active.filter(job => 
        job.data.workerQueueName === workerQueueName
      );
      const queueCompleted = completed.filter(job => 
        job.data.workerQueueName === workerQueueName
      );
      const queueFailed = failed.filter(job => 
        job.data.workerQueueName === workerQueueName
      );

      return {
        waitingJobs: queueWaiting.length,
        activeJobs: queueActive.length,
        completedJobs: queueCompleted.length,
        failedJobs: queueFailed.length,
        totalJobs: queueWaiting.length + queueActive.length + queueCompleted.length + queueFailed.length,
      };
    } catch (error) {
      this.logger.error(`Error obteniendo stats de ${workerQueueName}:`, error.message);
      return {
        waitingJobs: 0,
        activeJobs: 0,
        completedJobs: 0,
        failedJobs: 0,
        totalJobs: 0,
      };
    }
  }

  /**
   * Obtiene estadísticas de todas las worker queues
   * @returns Array con estadísticas de cada worker queue
   */
  async getAllWorkerQueuesStats() {
    const allWorkerQueues = await this.queueConfigService.getAllWorkerQueues();

    const stats = await Promise.all(
      allWorkerQueues.map(async (queueConfig) => {
        const queueStats = await this.getWorkerQueueStats(queueConfig.workerQueueName);
        return {
          workerQueueName: queueConfig.workerQueueName,
          concurrency: queueConfig.workerQueueConcurrency,
          assignedServices: queueConfig.assignedServices,
          ...queueStats,
          loadPercentage: queueConfig.workerQueueConcurrency > 0 
            ? Math.round((queueStats.activeJobs / queueConfig.workerQueueConcurrency) * 100)
            : 0,
        };
      })
    );

    return stats;
  }

  /**
   * Obtiene el estado del load balancer
   * @returns Resumen del estado actual
   */
  async getLoadBalancerStatus() {
    const allStats = await this.getAllWorkerQueuesStats();
    const totalWaiting = allStats.reduce((sum, stat) => sum + stat.waitingJobs, 0);
    const totalActive = allStats.reduce((sum, stat) => sum + stat.activeJobs, 0);
    const totalConcurrency = allStats.reduce((sum, stat) => sum + stat.concurrency, 0);

    return {
      totalWorkerQueues: allStats.length,
      totalWaitingJobs: totalWaiting,
      totalActiveJobs: totalActive,
      totalConcurrency,
      overallLoad: totalConcurrency > 0 ? Math.round((totalActive / totalConcurrency) * 100) : 0,
      workerQueues: allStats,
      recommendations: this.generateRecommendations(allStats),
    };
  }

  /**
   * Genera recomendaciones basadas en las estadísticas actuales
   * @param stats Estadísticas de worker queues
   * @returns Array de recomendaciones
   */
  private generateRecommendations(stats: any[]): string[] {
    const recommendations: string[] = [];

    // Detectar worker queues sobrecargadas
    const overloaded = stats.filter(stat => stat.loadPercentage >= 90);
    if (overloaded.length > 0) {
      recommendations.push(
        `Worker queues sobrecargadas: ${overloaded.map(q => q.workerQueueName).join(', ')} - considerar aumentar concurrencia`
      );
    }

    // Detectar worker queues subutilizadas
    const underutilized = stats.filter(stat => stat.loadPercentage <= 10 && stat.concurrency > 1);
    if (underutilized.length > 0) {
      recommendations.push(
        `Worker queues subutilizadas: ${underutilized.map(q => q.workerQueueName).join(', ')} - considerar reducir concurrencia`
      );
    }

    // Detectar acumulación de trabajos
    const withBacklog = stats.filter(stat => stat.waitingJobs > 10);
    if (withBacklog.length > 0) {
      recommendations.push(
        `Acumulación de trabajos en: ${withBacklog.map(q => q.workerQueueName).join(', ')} - considerar crear worker queue adicional`
      );
    }

    if (recommendations.length === 0) {
      recommendations.push('Sistema balanceado correctamente');
    }

    return recommendations;
  }
}