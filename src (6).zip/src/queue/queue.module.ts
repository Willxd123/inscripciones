import { ServiceLoadBalancerService } from './service-load-balancer.service';
import { DetalleInscripcionModule } from './../detalle-inscripcion/detalle-inscripcion.module';
import { BoletaHorarioModule } from './../boleta-horario/boleta-horario.module';
import { GestionModule } from './../gestion/gestion.module';
import { PeriodoModule } from './../periodo/periodo.module';
import { NotaModule } from './../nota/nota.module';
import { InscripcionModule } from './../inscripcion/inscripcion.module';
import { ModuloModule } from './../modulo/modulo.module';
import { AulaModule } from './../aula/aula.module';
import { HorarioModule } from './../horario/horario.module';
import { DocenteModule } from './../docente/docente.module';
import { GrupoMateriaModule } from './../grupo-materia/grupo-materia.module';
import { GrupoModule } from './../grupo/grupo.module';
import { PrerequisitoModule } from './../prerequisito/prerequisito.module';
import { MateriaModule } from './../materia/materia.module';
import { NivelModule } from './../nivel/nivel.module';
import { EstudianteModule } from './../estudiante/estudiante.module';
import { PlanEstudioModule } from '../plan-estudio/plan-estudio.module';
import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';

import { QueueConfigService } from './queue-config.service';
import { QueueController } from './queue.controller';
import { AuthModule } from '../auth/auth.module';
import {
  GenericQueueProcessor,
  GENERIC_QUEUE,
} from './generic-queue.processor';
import { GenericWrapperService } from './generic-wrapper.service';
import { CarreraModule } from '../carrera/carrera.module';

// Función helper para manejar retención configurable
function parseRetentionValue(envValue: string | undefined, defaultValue: number): number | false {
  if (!envValue) return defaultValue;
  if (envValue.toLowerCase() === 'false') return false;
  const parsed = parseInt(envValue, 10);
  return isNaN(parsed) ? defaultValue : parsed;
}

@Module({
  imports: [
    
    BullModule.registerQueue({
      name: GENERIC_QUEUE,
      // Configuraciones adicionales para mejor rendimiento
      defaultJobOptions: {
        removeOnComplete: false,
        removeOnFail: false,
        attempts: parseInt(process.env.QUEUE_DEFAULT_ATTEMPTS || '2'),
        backoff: {
          type: 'exponential',
          delay: parseInt(process.env.QUEUE_DEFAULT_DELAY || '1000'),
        },
      },
    }),
    forwardRef(() => AuthModule),
    forwardRef(() => CarreraModule),
    forwardRef(() => PlanEstudioModule),
    forwardRef(() => EstudianteModule),
    forwardRef(() => NivelModule),
    forwardRef(() => MateriaModule),
    forwardRef(() => PrerequisitoModule),
    forwardRef(() => GrupoModule),
    forwardRef(() => GrupoMateriaModule),
    forwardRef(() => DocenteModule),
    forwardRef(() => HorarioModule),
    forwardRef(() => AulaModule),
    forwardRef(() => ModuloModule),
    forwardRef(() => InscripcionModule),
    forwardRef(() => NotaModule),
    forwardRef(() => PeriodoModule),
    forwardRef(() => GestionModule),
    forwardRef(() => BoletaHorarioModule),
    forwardRef(() => DetalleInscripcionModule),
  ],
  controllers: [QueueController],
  providers: [QueueConfigService, GenericQueueProcessor, GenericWrapperService,ServiceLoadBalancerService],
  exports: [QueueConfigService, GenericWrapperService, ServiceLoadBalancerService],
})
export class QueueModule {}